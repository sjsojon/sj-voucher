<?php
header("Content-Type: application/json");

$host = "sql105.infinityfree.com";
$username = "if0_39336830";
$password = "iGHrl7wrFoyrrh";
$dbname = "if0_39336830_sj_voucher";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed!"]);
    exit();
}

$email = trim($_POST['email'] ?? '');
$newPass = $_POST['password'] ?? '';
$confirmPass = $_POST['confirm_password'] ?? '';

// Validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match("/@gmail\.com$/", $email)) {
    echo json_encode(["status" => "error", "message" => "Please enter a valid Gmail address."]);
    exit();
}

if (strlen($newPass) < 8) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 8 characters."]);
    exit();
}

if ($newPass !== $confirmPass) {
    echo json_encode(["status" => "error", "message" => "Passwords do not match."]);
    exit();
}

// Check if user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "No account found with this Gmail."]);
    exit();
}
$stmt->close();

// Update password
$hashed = password_hash($newPass, PASSWORD_DEFAULT);
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->bind_param("ss", $hashed, $email);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Your password has been successfully reset!"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to reset password. Try again."]);
}

$stmt->close();
$conn->close();
?>