<?php
header("Content-Type: application/json");

$host = "sql105.infinityfree.com";
$username = "if0_39336830";
$password = "iGHrl7wrFoyrrh";
$dbname = "if0_39336830_sj_voucher";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "AHHA..! Database connection failed!"]);
    exit();
}

$email = trim($_POST['email'] ?? '');
$pass = $_POST['password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

if (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
    echo json_encode(["status" => "error", "message" => "HEY..! Please enter a valid Gmail address!"]);
    exit();
}

if (strlen($pass) < 8) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 8 characters!"]);
    exit();
}

if ($pass !== $confirm) {
    echo json_encode(["status" => "error", "message" => "HMM..! Passwords do not match!"]);
    exit();
}

$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->close();
    echo json_encode(["status" => "error", "message" => "OPPS..! This Gmail is already registered!"]);
    exit();
}
$stmt->close();

$hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $hashed_pass);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "HURRAY..! Now You are part of the SJ Voucher Express"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to register. Please try again."]);
}
$stmt->close();
$conn->close();
?>