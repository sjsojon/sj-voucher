<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

$host = "sql105.infinityfree.com";
$username = "if0_39336830";
$password = "iGHrl7wrFoyrrh";
$dbname = "if0_39336830_sj_voucher";

$conn = new mysqli($host, $username, $password, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
        exit("Invalid Gmail address.");
    }

    // Check if user exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows === 0) {
        exit("No account with this Gmail found.");
    }

    // Generate token
    $token = bin2hex(random_bytes(30));
    $expires = date("Y-m-d H:i:s", strtotime("+15 minutes"));

    // Store token
    $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $token, $expires);
    $stmt->execute();

    // Send email
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'aturkey893@gmail.com';  // Replace
        $mail->Password   = 'syet zxvf wbuq cofu';    // Replace with Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('aturkey893@gmail.com', 'SJ Voucher Express');   //your gmail 
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Reset Your Password';
        $mail->Body    = "Click below to reset your password:<br><br>
                          <a href='https://sjvoucher.rf.gd/reset-password.php?token=$token'>Reset Password</a><br><br>
                          This link will expire in 15 minutes.";

        $mail->send();
        echo "Reset link sent! Please check your Gmail.";
    } catch (Exception $e) {
        echo "Email failed: {$mail->ErrorInfo}";
    }
}
?>