<?php
$DB_HOST = "sql105.infinityfree.com";
$DB_USER = "if0_39336830";
$DB_PASS = "iGHrl7wrFoyrrh";
$DB_NAME = "if0_39336830_sj_voucher";

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}