<?php
session_start();
header("Content-Type: application/json");

// Database config
$host = "sql105.infinityfree.com";
$username = "if0_39336830";
$password = "iGHrl7wrFoyrrh";
$dbname = "if0_39336830_sj_voucher";

// Message Bank
$messages = [
    "ERR_DB_CONN_001" => "OH SNAP..! Database connection failed. Please try again later!",
    "ERR_FORM_BLANK_005" => "Oops..! Both email and password fields are required!",
    "ERR_EMAIL_FORMAT_002" => "HEY..! Please enter a valid Gmail address (must end with @gmail.com)!",
    "ERR_NO_ACCOUNT_003" => "SORRY..! No account found with this Gmail. Try registering first!",
    "ERR_WRONG_PASSWORD_004" => "HMM..! The password you entered is incorrect. Try again!",
    "SUCCESS_LOGIN_200" => "WELCOME..! You’ve logged in successfully to SJ Voucher Express!"
];

// Connect to database
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => $messages["ERR_DB_CONN_001"]]);
    exit();
}

// Input
$email = trim($_POST['email'] ?? '');
$pass = $_POST['password'] ?? '';

// Validation
if (empty($email) || empty($pass)) {
    echo json_encode(["status" => "error", "message" => $messages["ERR_FORM_BLANK_005"]]);
    exit();
}

if (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
    echo json_encode(["status" => "error", "message" => $messages["ERR_EMAIL_FORMAT_002"]]);
    exit();
}

// Check user existence
$stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => $messages["ERR_NO_ACCOUNT_003"]]);
    exit();
}

$stmt->bind_result($hashed_password);
$stmt->fetch();

// Password check
if (password_verify($pass, $hashed_password)) {
    $_SESSION['user_email'] = $email;
    echo json_encode(["status" => "success", "message" => $messages["SUCCESS_LOGIN_200"]]);
} else {
    echo json_encode(["status" => "error", "message" => $messages["ERR_WRONG_PASSWORD_004"]]);
}

$stmt->close();
$conn->close();
?>